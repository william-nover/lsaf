<link href="css/index.php" rel="stylesheet" type="text/css" />
<style type="text/css">
div.file{width:<?php echo $this->config['thumbWidth'] ?>px;}
div.file .thumb{width:<?php echo $this->config['thumbWidth'] ?>px;height:<?php echo $this->config['thumbHeight'] ?>px}
</style>
<link href="themes/<?php echo $this->config['theme'] ?>/css.php" rel="stylesheet" type="text/css" />
