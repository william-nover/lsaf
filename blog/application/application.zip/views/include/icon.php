<meta name="theme-color" content="#0071BC">
<meta name="msapplication-navbutton-color" content="#0071BC">
<meta name="apple-mobile-web-app-status-bar-style" content="#0071BC">

<link rel="shortcut icon" type="image/x-icon" href="<?php echo IMAGES_BASE_URL;?>/icon/favicon.ico">

