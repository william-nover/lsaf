<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-141189357-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-141189357-1');
</script>
<!-- Google Tag Manager -->
<script type="text/javascript">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MWRBHLM');</script>
<!-- End Google Tag Manager -->

<script type="text/javascript">
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '375430072652637',
      xfbml      : true,
      version    : 'v3.3'
    });
  
    FB.AppEvents.logPageView();
  
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "https://connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "AutoRental",
  "name": "Sewa Mobil Box Jakarta",
  "image": "https://mobilboxjakarta.com/assets/images/logo-white.png",
  "@id": "",
  "url": "https://mobilboxjakarta.com/",
  "telephone": "+6282188821661",
  "priceRange": "IDR 120,000",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Jl. Baiduri Bulan Kelurahan No.58, RT.6/RW.11, Bidara Cina, Kecamatan Jatinegara",
    "addressLocality": "Jakarta",
    "postalCode": "13330",
    "addressCountry": "ID"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": -6.240840,
    "longitude": 106.865870
  },
  "openingHoursSpecification": {
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": [
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
      "Sunday"
    ],
    "opens": "00:00",
    "closes": "23:59"
  },
  "sameAs": [
    "https://www.facebook.com/mobilboxjakartacom/",
    "https://www.instagram.com/sewa.mobilbox/",
    "https://twitter.com/sewa_mobilbox"
  ]
}
</script>