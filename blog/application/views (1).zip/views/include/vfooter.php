<section class="wow fadeIn bg-medium-light-gray">
            <div class="container">
                <div class="row sm-col-2-nth">
                    <!-- start contact item -->
                    <div class="col-md-4 col-sm-4 col-xs-12 text-center sm-margin-30px-bottom wow fadeInUp last-paragraph-no-margin">
                        <i class="icon-map-pin icon-medium margin-25px-bottom sm-margin-15px-bottom"></i>
                        <div class="text-extra-dark-gray text-uppercase text-small font-weight-600 alt-font margin-5px-bottom">Alamat</div>
                        <p class="center-col">
                            Jl. Baiduri Bulan. No 58 Kelurahan, RT.6/RW.11,<br>
                            Bidara Cina - Jatinegara,<br>
                            Jakarta Timur, Jakarta 13330</p>
                        <a href="https://g.page/mobil-box-jakarta-com" title="google map mobilboxjakarta" target="_blank" class="text-uppercase text-deep-pink text-small margin-15px-top xs-margin-10px-top display-inline-block" style="color:#f58a1f">GET DIRECTION</a>
                    </div>
                    <!-- end contact item -->
                    <div class="col-md-4 col-sm-4 col-xs-12 text-center sm-margin-30px-bottom wow fadeInUp last-paragraph-no-margin" data-wow-delay="0.2s">
                        <i class="icon-chat icon-medium margin-25px-bottom sm-margin-15px-bottom"></i>
                        <div class="text-extra-dark-gray text-uppercase text-small font-weight-600 alt-font margin-5px-bottom">No. kontak</div>
                        <p class="center-col">Hp/Wa: +62 821-8882-1661</p>
                        <a href="tel:+62 821-8882-1661" title="6282188821661" class="text-uppercase text-deep-pink text-small margin-15px-top xs-margin-10px-top display-inline-block " style="color:#f58a1f">call us</a>
                    </div>
                    <!-- start contact item -->
                    <div class="col-md-4 col-sm-4 col-xs-12 text-center xs-margin-30px-bottom wow fadeInUp last-paragraph-no-margin" data-wow-delay="0.4s">
                        <i class="icon-envelope icon-medium margin-25px-bottom sm-margin-15px-bottom"></i>
                        <div class="text-extra-dark-gray text-uppercase text-small font-weight-600 alt-font margin-5px-bottom">E-mail</div>
                        <p class="center-col"><a href="mailto:&#099;&#111;&#110;&#116;&#097;&#099;&#116;&#064;&#109;&#111;&#098;&#105;&#108;&#098;&#111;&#120;&#106;&#097;&#107;&#097;&#114;&#116;&#097;&#046;&#099;&#111;&#109;" title="contact@mobilboxjakarta.com">contact@mobilboxjakarta.com</a><br><a href="mailto:&#105;&#110;&#102;&#111;&#064;&#109;&#111;&#098;&#105;&#108;&#098;&#111;&#120;&#106;&#097;&#107;&#097;&#114;&#116;&#097;&#046;&#099;&#111;&#109;" title="info@mobilboxjakarta.com">info@mobilboxjakarta.com</a></p>
                        <a href="<?=BASE_URL?>/contact" title="contact" class="text-uppercase text-small margin-15px-top xs-margin-10px-top display-inline-block" style="color:#f58a1f">send e-mail</a>
                    </div>
                </div>
            </div>
        </section>
<footer class="footer-strip-dark bg-black padding-50px-tb xs-padding-30px-tb">
            <div class="container">
                <div class="row equalize xs-equalize-auto">
                    <!-- start logo -->
                    <div class="col-md-3 col-sm-3 col-xs-12 display-table sm-text-center xs-margin-20px-bottom">
                        <div class="display-table-cell vertical-align-middle">
                            <a href="<?=BASE_URL;?>" title="home"><img class="footer-logo" src="<?= IMAGES_BASE_URL;?>/logo.png" data-rjs="<?= IMAGES_BASE_URL;?>/logo-white@2x.png" alt="logo sewa mobilbox jakarta" style="max-height: 60px"></a>
                        </div>
                    </div> 
                    <!-- end logo -->
                    <!-- start copyright -->
                    <div class="col-md-6 col-sm-6 col-xs-12 text-center text-small alt-font display-table xs-margin-10px-bottom text-white">
                        <div class="display-table-cell vertical-align-middle">
                            &copy; <?= @date('Y')?> Powered by  <a href="<?=BASE_URL;?>" target="_blank" title="Sewa Mobil Box Jakarta" style="color: #fff">Sewa Mobil Box Jakarta</a>.<br>
                       
                        </div>
                    </div>
                    <!-- end copyright -->
                    <!-- start social media -->
                    <div class="col-md-3 col-sm-3 col-xs-12 display-table text-right sm-text-center">
                        <div class="display-table-cell vertical-align-middle">
                            <div class="social-icon-style-8 display-inline-block vertical-align-middle">
                                <ul class="small-icon no-margin-bottom">
                                     <?php if($countSosmed > 0){
                                        $i=0;
                                        foreach($ListSosmed as $loc){  $i++;  
                                        ?>
                                             <li><a class="facebook text-white" title="facebook" href="<?= html_entity_decode(contentValue($loc, 'fb'));?>/" target="_blank"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
                                             <li><a class="twitter text-white" title="twitter" href="<?= html_entity_decode(contentValue($loc, 'tw'));?>" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                             <li><a class="google text-white" title="google" href="<?= html_entity_decode(contentValue($loc, 'gp'));?>" target="_blank"><i class="fab fa-google-plus-g"></i></a></li>
                                             <li><a class="instagram text-white" title="instagram" href="<?= html_entity_decode(contentValue($loc, 'ig'));?>" target="_blank"><i class="fab fa-instagram no-margin-right" aria-hidden="true"></i></a></li>                   
                                     <?php }}?>                        
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- end social media -->
                </div>
            </div>
        </footer>
        
        <span style="display:none;">jasa pindahan, jasa antar barang, sewa mobil box murah, sewa mobil pickup, sewa truk, sewa mobil blind van, sewa mobil box</span>

     <!-- start scroll to top -->
     <a class="scroll-top-arrow" href="javascript:void(0);" title="back to top"><i class="ti-arrow-up"></i></a>
      <!-- end scroll to top  -->
      <a href="https://api.whatsapp.com/send?phone=6282188821661&text=Hi%20https://mobilboxjakarta.com%20saya%20ingin%20bertanya%20"  target="_blank" title="whatsapp">
      <i class="whatsapp"></i>
    </a>