<?php 
    $ci =& get_instance();
    $ci->load->model('web/Model_content');
    $ListSosmed =array();
    $ListLoc =array();
    
    $sosmed=121;
    $string =$sosmed;
    $arrayin=array_map('intval', explode(',', $string));
    $where_in = implode(",",$arrayin);
    $order_sosmed='';
    $order_sosmed .= " order by a.row_order ASC";
    $order_sosmed .= " limit  0, 8";
    $whereSosmed = '';
    $whereSosmed .= " WHERE a.row_active_status=1 and a.row_active_status=1 and a.row_parent=0 and a.module_id in(".$where_in.") ";            
    $ListSosmedAll = $ci->Model_content->getListContent($whereSosmed,$order_sosmed);        
    foreach ($ListSosmedAll as $lc){
                    if ($lc['module_id']== $sosmed){
                        $ListSosmed[]=$lc; 
                        $countSosmed = count($ListSosmed);
                    } 
                }
    ?>
<header>
            <!-- start navigation -->
            <nav class="navbar navbar-default bootsnav background-white navbar-expand-lg">
                <div class="container nav-header-container">
                    <!-- start logo -->
                    <div class="col-auto pl-0">
                        <a href="<?=BASE_URL;?>" title="logo" class="logo">
                            <img src="<?=IMAGES_BASE_URL;?>/logo.png" data-rjs="<?=IMAGES_BASE_URL;?>/logo.png" class="logo-light default" alt="logo">
                        </a>
                    </div>
                    <!-- end logo -->
                    <div class="col accordion-menu pr-0 pr-md-3">
                        <button type="button" class="navbar-toggler collapsed" data-toggle="collapse" data-target="#navbar-collapse-toggle-1">
                            <span class="sr-only">toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <div class="navbar-collapse collapse justify-content-end" id="navbar-collapse-toggle-1">
                            <ul id="accordion" class="nav navbar-nav navbar-left no-margin alt-font text-normal" data-in="fadeIn" data-out="fadeOut">
                                    <li class="<?php if($menu_id == '0') echo 'active'; ?>">
                                        <a href="<?=BASE_URL;?>" title="home">Home</a>
                                    </li>    
                                    <li class="<?php if($menu_id == '1') echo 'active'; ?>">
                                        <a href="<?=BASE_URL;?>/about.html" title="about us">About Us</a>
                                    </li>
                                    <!-- end menu item -->
                                    <li class="<?php if($menu_id == '2') echo 'active'; ?>">
                                        <a href="<?=BASE_URL;?>/armada.html" title="armada">Armada</a>
                                    </li>
                                    <li class="<?php if($menu_id == '3') echo 'active'; ?>">
                                        <a href="<?=BASE_URL;?>/gallery.html" title="gallery" >Gallery</a>
                                    </li>
                                    <li class="<?php if($menu_id == '4') echo 'active'; ?>">
                                        <a href="<?=BASE_URL;?>/blog.html" title="Blog">Blog</a>
                                    </li>
                                    <li class="<?php if($menu_id == '7') echo 'active'; ?>">
                                        <a href="<?=BASE_URL;?>/bantuan.html" title="Bantuan"> Bantuan</a>
                                    </li>
                                    <li class="<?php if($menu_id == '6') echo 'active'; ?>">
                                        <a href="<?=BASE_URL;?>/contact.html" title="contact">Contact</a>
                                    </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-auto pr-lg-0">
                        <div class="header-social-icon d-none d-md-inline-block">
                             <?php if($countSosmed > 0){
                                $i=0;
                                foreach($ListSosmed as $loc){  $i++;  
                                ?>
                                            <a title="facebook" href="<?= html_entity_decode(contentValue($loc, 'fb'));?>/" target="_blank"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
                                            <a title="twitter" href="<?= html_entity_decode(contentValue($loc, 'tw'));?>" target="_blank"><i class="fab fa-twitter"></i></a>
                                            <a title="google" href="<?= html_entity_decode(contentValue($loc, 'gp'));?>" target="_blank"><i class="fab fa-google-plus-g"></i></a>
                                            <a title="instagram" href="<?= html_entity_decode(contentValue($loc, 'ig'));?>" target="_blank"><i class="fab fa-instagram no-margin-right" aria-hidden="true"></i></a>
                                        <?php }}?>  
                         </div>
                    </div>
                </div>
            </nav>
            <!-- end navigation --> 
        </header>
