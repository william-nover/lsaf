<!doctype html>
<html class="no-js" lang="id">
    <head>
        <!-- title -->
       <title>Armada | Sewa Mobil Box Jakarta</title>
    <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
         <meta name="author" content="Mobilbox Jakarta">
        <meta property="og:type" content="website" />
       <meta property="og:title" content="Sewa Mobil Box Murah Cepat &amp; Terbaik di Jakarta" />
        <meta property="og:description" content="mobilboxjakarta.com adalah jasa sewa mobil blind van, pickup box dan truk box murah untuk pindahan rumah, kantor dan jasa angkut barang lain." />
        <meta property="og:image" content="<?= IMAGES_BASE_URL; ?>/logo.png" />
        <meta name="description" content="mobilboxjakarta.com adalah jasa sewa mobil blind van, pickup box dan truk box murah untuk pindahan rumah, kantor dan jasa angkut barang lain." />
        <meta name="keywords" content="jasa pindahan, jasa antar barang, sewa mobil box murah, sewa mobil pickup, sewa truk, sewa mobil blind van, sewa mobil box">
         <?php include 'include/icon.php';?>
    <!-- bootstrap -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous" media="all">
      <!-- et line icon --> 
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css" media="all">
      <!-- font-awesome icon -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.min.css" media="all">
      <!-- style -->
      <link rel="stylesheet" href="<?= FRONTEND_BASE_URL; ?>/css/style.css" media="all">
      <script>
         !function(t){"use strict";t.loadCSS||(t.loadCSS=function(){});var e=loadCSS.relpreload={};if(e.support=function(){var e;try{e=t.document.createElement("link").relList.supports("preload")}catch(t){e=!1}return function(){return e}}(),e.bindMediaToggle=function(t){var e=t.media||"all";function a(){t.media=e}t.addEventListener?t.addEventListener("load",a):t.attachEvent&&t.attachEvent("onload",a),setTimeout(function(){t.rel="stylesheet",t.media="only x"}),setTimeout(a,3e3)},e.poly=function(){if(!e.support())for(var a=t.document.getElementsByTagName("link"),n=0;n<a.length;n++){var o=a[n];"preload"!==o.rel||"style"!==o.getAttribute("as")||o.getAttribute("data-loadcss")||(o.setAttribute("data-loadcss",!0),e.bindMediaToggle(o))}},!e.support()){e.poly();var a=t.setInterval(e.poly,500);t.addEventListener?t.addEventListener("load",function(){e.poly(),t.clearInterval(a)}):t.attachEvent&&t.attachEvent("onload",function(){e.poly(),t.clearInterval(a)})}"undefined"!=typeof exports?exports.loadCSS=loadCSS:t.loadCSS=loadCSS}("undefined"!=typeof global?global:this);
      </script>
      <!--[if IE]>
      <script src="<?= FRONTEND_BASE_URL; ?>/js/html5shiv.js" defer></script>
      <![endif]-->
         <?php include 'include/analytics.php';?>
        
    </head>

    <body> 
         <?php include 'include/tagmanager.php';?>
        <!-- start header -->
        <?php include 'include/vheader.php';?>
        <!-- start page title section -->
         
        <!-- start interactive banners style 02 section -->
        <section class="wow fadeIn cover-background background-position-top top-space" style="background-image:url('<?= IMAGES_BASE_URL; ?>/armada.webp');">
            <div class="opacity-medium bg-extra-dark-gray"></div>
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 d-flex flex-column text-center justify-content-center page-title-large padding-30px-tb">
                        <!-- start sub title -->
                        <span class="d-block text-white-2 opacity6 alt-font margin-5px-bottom">Anda bisa memilih sesuai kebutuhan</span>
                        <!-- end sub title -->
                        <!-- start page title -->
                        <h1 class="alt-font text-white-2 font-weight-600 mb-0">Armada Kami</h1>
                        <!-- end page title -->
                    </div>
                </div>
            </div>
        </section>
         <section class="wow fadeIn padding-20px-tb border-bottom border-color-extra-light-gray">
              <div class="container-fluid">
                <div class="row">
                    <div class="col-12 header" id="myFilter">
                        <!-- start filter navigation -->
                        <ul id="myUl" class="portfolio-filter nav nav-tabs justify-content-center border-0 portfolio-filter-tab-1 font-weight-600 alt-font text-uppercase text-center margin-80px-bottom text-small md-margin-40px-bottom sm-margin-20px-bottom">
                            <li class="nav active"><a href="javascript:void(0);" data-filter="*" class="btn btn-deep-pink btn-small text-white-2 text-very-small">All</a></li>
                            <?php
                                if($countParent > 0){
                                $i=0;
                                foreach($ListParent as $ls){
                                $i++; ?> 
                            <li class="nav"><a href="javascript:void(0);" data-filter=".filter-<?=$ls['category_id'];?>" class="btn btn-deep-pink btn-small text-white-2 text-very-small"><?=$ls['category_title']; ?></a></li>
                             <?php } } ?>
                            </ul>                                                                           
                        <!-- end filter navigation -->
                    </div>
                </div>
            </div>
            <div class="container" id="filter-container">
                <div class="row">
                    <div class="col-12 px-3 p-md-0">
                        <div class="filter-content overflow-hidden">
                            <ul class="portfolio-grid work-3col gutter-medium hover-option6 lightbox-portfolio">
                                <li class="grid-sizer"></li>
                                <!-- start portfolio-item item -->
                             <?php
                              if($countContent > 0){
                              $i=0;
                              foreach($ListContent as $ls){
                              $i++;
                              if ($ls['row_alias'] !=''){                          
                                  $ref =BASE_URL.'/'.$ls['row_alias'];
                                  }                       
                                  else {                          
                               $ref = BASE_URL.'/'.$controller.'/detail/'.$ls['row_id'];           
                               }  
                              ?>  
                                <li class="filter-<?=$ls['category_id'];?> grid-item wow fadeInUp last-paragraph-no-margin">
                                    <figure>
                                        <div class="portfolio-img bg-deep-pink position-relative text-center overflow-hidden">
                                            <img src="<?= html_entity_decode(contentValue($ls, 'images'));?>" alt="<?= html_entity_decode(contentValue($ls, 'title'));?>"/>
                                            <div class="portfolio-icon">
                                                <a href="<?= $ref; ?>"><i class="fas fa-link text-extra-dark-gray" aria-hidden="true"></i></a>                                                
                                            </div>
                                            
                                        </div>
                                        <figcaption class="bg-white">
                                            <div class="portfolio-hover-main text-center">
                                                <div class="portfolio-hover-box align-middle">
                                                    <div class="portfolio-hover-content position-relative">
                                                        <a href="<?= $ref; ?>"><span class="line-height-normal font-weight-600 text-small alt-font margin-5px-bottom text-extra-dark-gray text-uppercase d-block"><?= html_entity_decode(contentValue($ls, 'title'));?></span></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </li>
                                
                                 <?php } } ?>
                                <!-- end portfolio item -->
                               
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section> 
        
        <?php include 'include/vfooter.php';?>
         <script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("myFilter");
var ulFix = document.getElementById("myUl");
var fixeds = header.offsetTop;
 var elem = document.querySelector('#filter-container');
function myFunction() {
    
  if (window.pageYOffset > fixeds) {
    header.classList.add("fixeds");
    ulFix.classList.add("filter-fixed");
    elem.classList.add("filter-container");

// Set color to purple
elem.style.color = 'purple';
  } else {
    header.classList.remove("fixeds");
    ulFix.classList.remove("filter-fixed");
    elem.classList.remove("filter-container");
  }
}
</script>
      
<style type="text/css"> 
.header { 
height: 50px;
z-index: 9999;
background-color: #fff!important;
}
.filter-fixed{
padding-top: 15px;
     
}
.fixeds {
width: 100%;
position: fixed;
top: 0;
}
.filter-container {
 margin-top: 100px;
}
@media (max-width: 767px){
  .header { 
height: 70px;
  }
}
</style>
        <!-- end footer -->
    
        <!-- javascript libraries -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.js" defer></script>
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/modernizr.js" defer></script>
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/bootstrap.min.js" defer></script>
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.easing.1.3.js" defer></script>
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/skrollr.min.js" defer></script>
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/smooth-scroll.js" defer></script>
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.appear.js" defer></script>
        <!-- menu navigation -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/bootsnav.js" defer></script>
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.nav.js" defer></script>
        <!-- animation -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/wow.min.js" defer></script>
        <!-- page scroll -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/page-scroll.js" defer></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/swiper.min.js" defer></script>
        <!-- counter -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.count-to.js" defer></script>
        <!-- parallax -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.stellar.js" defer></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.magnific-popup.min.js" defer></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/isotope.pkgd.min.js" defer></script>
        <!-- images loaded -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/imagesloaded.pkgd.min.js" defer></script>
        <!-- pull menu -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/classie.js" defer></script>
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/hamburger-menu.js" defer></script>
        <!-- counter  -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/counter.js" defer></script>
        <!-- fit video  -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.fitvids.js" defer></script>
        <!-- equalize -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/equalize.min.js" defer></script>
       <!-- justified gallery  -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/justified-gallery.min.js" defer></script>
       <!-- instagram -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/instafeed.min.js" defer></script>
        <!-- retina -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/retina.min.js" defer></script>
       
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/main.js" defer></script>
    </body>
</html>