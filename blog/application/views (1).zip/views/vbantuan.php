<!doctype html>
<html class="no-js" lang="id">
   <head>
      <!-- title -->
      <title>Bantuan | Sewa Mobil Box Jakarta</title>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
      <meta name="author" content="Mobilbox Jakarta">
      <meta property="og:type" content="website" />
     <meta property="og:title" content="Sewa Mobil Box Murah Cepat &amp; Terbaik di Jakarta" />
        <meta property="og:description" content="mobilboxjakarta.com adalah jasa sewa mobil blind van, pickup box dan truk box murah untuk pindahan rumah, kantor dan jasa angkut barang lain." />
        <meta property="og:image" content="<?= IMAGES_BASE_URL; ?>/logo.png" />
        <meta name="description" content="mobilboxjakarta.com adalah jasa sewa mobil blind van, pickup box dan truk box murah untuk pindahan rumah, kantor dan jasa angkut barang lain." />
        <meta name="keywords" content="jasa pindahan, jasa antar barang, sewa mobil box murah, sewa mobil pickup, sewa truk, sewa mobil blind van, sewa mobil box">
         <?php include 'include/icon.php';?>
      <!-- bootstrap -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous" media="all">
      <!-- et line icon --> 
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css" media="all">
      <!-- font-awesome icon -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.min.css" media="all">
      <!-- style -->
      <link rel="stylesheet" href="<?= FRONTEND_BASE_URL; ?>/css/style.css" media="all">
      <!-- responsive css -->
      <link rel="stylesheet" href="<?= FRONTEND_BASE_URL; ?>/css/responsive.css" />
      <!--[if IE]>
      <script src="<?= FRONTEND_BASE_URL; ?>/js/html5shiv.js"></script>
      <![endif]-->
      <style type="text/css">
         .panel-title { font-size: 16px;}
         /* accordion style1 */
         .accordion-style1 .panel  {background: transparent; box-shadow: none; margin-top: 0 !important}
         .accordion-style1.panel-group .panel-heading  {border: 0px; border-bottom: 1px solid #e4e4e4;}
         .accordion-style1 .panel-heading {padding: 16px 0;}
         .accordion-style1 .panel-title {font-size: 13px; padding-right: 30px; position: relative}
         .accordion-style1 .panel-title > span.float-right { position: absolute; right: 0; top: 0; }
         .accordion-style1 .panel-heading i {font-size: 12px; color: #626262}
         .accordion-style1.panel-group .panel-heading+.panel-collapse>.list-group, .accordion-style1.panel-group .panel-heading+.panel-collapse>.panel-body{border-top:0; padding: 25px 0}
     [data-toggle="collapse"] .fa:before {  
  content: "\f139";
}

[data-toggle="collapse"].collapsed .fa:before {
  content: "\f13a";
}
      </style>
      <?php include 'include/analytics.php';?>
   </head>
   <body>
      <?php include 'include/tagmanager.php';?>
      <!-- start header -->
      <?php include 'include/vheader.php';?>
      <!-- start page title section -->
      <!-- start interactive banners style 02 section -->
      <section class="wow fadeIn cover-background background-position-top top-space" style="background-image:url('<?= IMAGES_BASE_URL; ?>/faq.jpg');">
         <div class="opacity-medium bg-extra-dark-gray"></div>
         <div class="container">
            <div class="row align-items-center">
               <div class="col-12 d-flex flex-column text-center justify-content-center page-title-small padding-30px-tb">
                  <!-- start page title -->
                  <h1 class="alt-font text-white-2 font-weight-400 mb-0">Pertanyaan-pertanyaan yang sering ditanyakan.</h1>
                  <!-- end page title -->
               </div>
            </div>
         </div>
      </section>
      <!-- end page title section -->
      <!-- start accordions style 01 section -->
      <section class="wow fadeIn">
         <div class="container">
            <div class="row justify-content-center">
               <div class="col-12 col-lg-8">
                  <!-- start accordion -->
                  <div class="panel-group accordion-style1" id="accordion-design">
                     <!-- start accordion item -->
                     <div class="panel">
                        <div class="panel-heading">
                           <a data-toggle="collapse" data-parent="#accordion-design" href="#pesan" class="collapsed" aria-expanded="false">
                              <div class="panel-title font-weight-500 text-extra-dark-gray text-uppercase">
                                  1. Bagaimana cara melakukan pemesanan?
                               <span class="float-right"> <i class="fa" aria-hidden="true"></i></span></div>
                           </a>
                        </div>
                        <div id="pesan" class="panel-collapse collapse show" data-parent="#accordion-design" aria-expanded="false" role="tablist">
                           <div class="panel-body">
                            <ul class="p-md-0 list-style-1">
                            <li>Buka Website kami di <mark class="bg-warning text-white-2"><a href="https://mobilboxjakarta.com">www.mobilboxjakarta.com</a></mark> atau <mark class="bg-warning text-white-2"><a href="https://sewa-mobilboxjakarta.com">www.sewa-mobilboxjakarta.com</a></mark></li>
                            <li>Pilih armada sesuai kebutuhan anda dan lakukan pemesanan</li>
                            <li>Anda bisa memesan melalui whatsapp atau mengisi form di halaman <mark class="bg-warning text-white-2"><a href="<?=BASE_URL?>/contact">contact</a></mark> </li>
                            <li>Kami akan langsung menghubungi anda untuk proses selanjutanya</li>
                            </ul>
                           </div>
                        </div>
                     </div>
                     <!-- end accordion item -->
                     <!-- start accordion item -->
                     <div class="panel">
                        <div class="panel-heading">
                           <a data-toggle="collapse" data-parent="#accordion-design" href="#harga" class="collapsed" aria-expanded="false">
                            <div class="panel-title font-weight-500 text-extra-dark-gray text-uppercase">
                                 2. Bagaimana saya tau harga?<span class="float-right"> 
                                     <i class="fa" aria-hidden="true"></i></span>
                            </div>
                           </a>
                        </div>
                        <div id="harga" class="panel-collapse collapse" data-parent="#accordion-design" aria-expanded="false" role="tablist">
                            <div class="panel-body">
                                Kami memang tidak menyediakan daftar harga di website, akan tetapi anda akan megetahuinya setelah menghubungi kami dan melakukan penawaran.
                            </div>
                        </div>
                     </div>
                     <!-- end accordion item -->
                     <!-- start accordion item -->
                     <div class="panel">
                        <div class="panel-heading">
                           <a data-toggle="collapse" data-parent="#accordion-design" href="#perubahan" class="collapsed" aria-expanded="false">
                              <div class="panel-title font-weight-500 text-extra-dark-gray text-uppercase">
                                  3. Apakah saya dapat melakukan perubahan pada order saya setelah mendapatkan penawaran? Apakah akan ada perubahan harga?
                                  <span class="float-right"> <i class="fa" aria-hidden="true"></i></span>
                              </div>
                           </a>
                        </div>
                        <div id="perubahan" class="panel-collapse collapse" data-parent="#accordion-design" aria-expanded="false" role="tablist">
                           <div class="panel-body">
                              Jika hanya waktu yang berubah dan jarak tempuh sama (sekalipun berubah lokasi) tentu tidak ada perubahan harga, akan tetapi jika jarak tempuh berubah tentu harga akan di sesuaikan bersama.   
                           </div>
                        </div>
                     </div>
                     <!-- end accordion item -->
                     <!-- start accordion item -->
                     <div class="panel">
                        <div class="panel-heading">
                           <a data-toggle="collapse" data-parent="#accordion-design" href="#pindahan" class="collapsed" aria-expanded="false">
                              <div class="panel-title font-weight-500 text-extra-dark-gray text-uppercase"> 
                                4. Apakah pengemudi membantu proses pindahan?
                                <span class="float-right"> <i class="fa" aria-hidden="true"></i></span>
                              </div>
                           </a>
                        </div>
                        <div id="pindahan" class="panel-collapse collapse" data-parent="#accordion-design" aria-expanded="false" role="tablist">
                           <div class="panel-body">
                              Tentu jika sebatas masih mudah untuk diangkat. Pengemudi akan membantu membawa dan mengatur barang-barang Anda untuk dimasukkan ke dalam kendaraan untuk pindahan dan demikian juga saat menurunkan barang. 
                           </div>
                        </div>
                     </div>
                     <!-- end accordion item -->
                     <!-- start accordion item -->
                     <div class="panel">
                        <div class="panel-heading">
                           <a data-toggle="collapse" data-parent="#accordion-design" href="#dilarang" class="collapsed" aria-expanded="false">
                              <div class="panel-title font-weight-500 text-extra-dark-gray text-uppercase">
                                  5. Adakah barang yang dilarang untuk diangkut?
                                  <span class="float-right"> <i class="fa" aria-hidden="true"></i></span>
                              </div>
                           </a>
                        </div>
                        <div id="dilarang" class="panel-collapse collapse" data-parent="#accordion-design" aria-expanded="false" role="tablist">
                           <div class="panel-body">
                             Kami tidak akan melakukan pengiriman barang yang dikategorikan sebagai barang berbahaya dan/atau barang yang dilarang, yang antara lain adalah:
                             <ul class="p-md-0 list-style-1">
                                 <li>Uang (koin, uang tunai dalam rupiah dan/atau mata uang asing lainnya), surat berharga (cheque, giro, obligasi, saham, sertifikat).</li>
                                 <li>Narkotika, ganja, morfin dan obat-obat atau zat-zat yang dianggap sebagai benda terlarang lainnya.</li>
                                 <li>Barang yang waktu hidupnya kurang dari transit time pengiriman yang diperkirakan.</li>
                                 <li>Barang dalam kategori berbahaya, beracun dan barang-barang kimia yang mudah meledak atau terbakar.</li>
                                 <li>Kiriman dalam bentuk cair lainnya kecuali dikemas dengan baik dan benar (dengan melampirkan Material Safety Data Sheet) dan surat pernyataan barang berbahaya dari Pelanggan).</li>
                                 <li>Barang yang mudah meledak, seperti senjata dan bagian-bagiannya.</li>
                                 <li>Barang-barang yang terbuat dari bahan gelas dan barang pecah belah (kecuali dikemas dengan baik dan memenuhi standar pengemasan).</li>
                             </ul>
                             </div>
                        </div>
                     </div>
                     <!-- end accordion item -->
                  </div>
                  <!-- end accordion -->
               </div>
            </div>
         </div>
      </section>
      
      <!-- end accordions style 01 section -->
      <?php include 'include/vfooter.php';?>
      <!-- javascript libraries -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/modernizr.js"></script>
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/bootstrap.bundle.js"></script>
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.easing.1.3.js"></script>
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/skrollr.min.js"></script>
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/smooth-scroll.js"></script>
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.appear.js"></script>
      <!-- menu navigation -->
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/bootsnav.js" defer></script>
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.nav.js" defer></script>
      <!-- animation -->
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/wow.min.js" defer></script>
      <!-- page scroll -->
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/page-scroll.js" defer></script>
      <!-- swiper carousel -->
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/swiper.min.js" defer></script>
      <!-- counter -->
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.count-to.js" defer></script>
      <!-- parallax -->
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.stellar.js" defer></script>
      <!-- magnific popup -->
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.magnific-popup.min.js" defer></script>
      <!-- portfolio with shorting tab -->
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/isotope.pkgd.min.js" defer></script>
      <!-- images loaded -->
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/imagesloaded.pkgd.min.js" defer></script>
      <!-- pull menu -->
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/classie.js" defer></script>
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/hamburger-menu.js" defer></script>
      <!-- justified gallery  -->
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/justified-gallery.min.js" defer></script>
       <!-- revolution -->
      <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/main.js" defer></script>
   </body>
</html>