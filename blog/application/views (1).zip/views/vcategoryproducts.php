<!doctype html>
<html class="no-js" lang="id">
    <head>
        <!-- title -->
        <title>Armada | Mobil Box Jakarta | Sewa Mobil Box  Termurah &amp; Berkualitas</title>
    <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
         <meta name="author" content="Mobilbox Jakarta">
        <meta property="og:type" content="website" />
        <meta property="og:title" content="Jasa Pindah & Angkut Barang Keseluruh Jabodetabek Mulai Dari Rp 121.000 Saja" />
        <meta property="og:description" content="MobilBoxJakarta  adalah jasa penyewaan kendaraan berupa mobil box, pickup dan truk cepat dan mudah. Tersedia untuk pindahan rumah, kantor dan jasa angkut barang lain." />
        <meta property="og:image" content="<?= IMAGES_BASE_URL; ?>/logo.png" />
        <meta name="description" content="MobilBoxJakarta adalah jasa penyewaan kendaraan berupa van, pickup dan truk on demand cepat dan mudah. Tersedia untuk pindahan rumah, kantor dan jasa angkut barang lain." />
         <meta name="keywords" content="mobil box, jasa pindahan, jasa antar barang, sewa mobil box murah, pickup, truk, van">
            <?php include 'include/icon.php';?>
        <!-- bootstrap -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous" media="all">
      <!-- et line icon --> 
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css" media="all">
      <!-- font-awesome icon -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.min.css" media="all">
      <!-- style -->
      <link rel="stylesheet" href="<?= FRONTEND_BASE_URL; ?>/css/style.css" media="all">
      <script>
         !function(t){"use strict";t.loadCSS||(t.loadCSS=function(){});var e=loadCSS.relpreload={};if(e.support=function(){var e;try{e=t.document.createElement("link").relList.supports("preload")}catch(t){e=!1}return function(){return e}}(),e.bindMediaToggle=function(t){var e=t.media||"all";function a(){t.media=e}t.addEventListener?t.addEventListener("load",a):t.attachEvent&&t.attachEvent("onload",a),setTimeout(function(){t.rel="stylesheet",t.media="only x"}),setTimeout(a,3e3)},e.poly=function(){if(!e.support())for(var a=t.document.getElementsByTagName("link"),n=0;n<a.length;n++){var o=a[n];"preload"!==o.rel||"style"!==o.getAttribute("as")||o.getAttribute("data-loadcss")||(o.setAttribute("data-loadcss",!0),e.bindMediaToggle(o))}},!e.support()){e.poly();var a=t.setInterval(e.poly,500);t.addEventListener?t.addEventListener("load",function(){e.poly(),t.clearInterval(a)}):t.attachEvent&&t.attachEvent("onload",function(){e.poly(),t.clearInterval(a)})}"undefined"!=typeof exports?exports.loadCSS=loadCSS:t.loadCSS=loadCSS}("undefined"!=typeof global?global:this);
      </script>
      <!--[if IE]>
      <script src="<?= FRONTEND_BASE_URL; ?>/js/html5shiv.js" defer></script>
      <![endif]-->
       
         <?php include 'include/analytics.php';?>
        
    </head>

    <body> 
         <?php include 'include/tagmanager.php';?>
        <!-- start header -->
        <?php include 'include/vheader.php';?>
        <!-- start page title section -->
         
        <!-- start interactive banners style 02 section -->
        <section class="wow fadeIn cover-background background-position-top top-space" style="background-image:url('<?= IMAGES_BASE_URL; ?>/armada.jpg');">
            <div class="opacity-medium bg-extra-dark-gray"></div>
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 d-flex flex-column text-center justify-content-center page-title-large padding-30px-tb">
                        <!-- start sub title -->
                        <span class="d-block text-white-2 opacity6 alt-font margin-5px-bottom">Anda bisa memilih sesuai kebutuhan</span>
                        <!-- end sub title -->
                        <!-- start page title -->
                        <h1 class="alt-font text-white-2 font-weight-600 mb-0">Armada Kami</h1>
                        <!-- end page title -->
                    </div>
                </div>
            </div>
        </section>
         <section class="wow fadeIn padding-20px-tb border-bottom border-color-extra-light-gray">
            <div class="container">
                <div class="row">
                    <div class="col-12 px-3 p-md-0">
                        <div class="filter-content overflow-hidden">
                            <ul class="portfolio-grid work-3col gutter-medium hover-option6 lightbox-portfolio">
                                <li class="grid-sizer"></li>
                                <!-- start portfolio-item item -->
                                <?php
                                if($countParent > 0){
                                $i=0;
                                foreach($ListParent as $ls){
                                $i++;
                                if ($ls['category_url'] !=''){                          
                                    $ref =BASE_URL.'/armada'.$ls['category_url'];
                                    }                       
                                    else {                          
                                 $ref = BASE_URL.'/armada/';          
                                 }  
                                ?> 
                                <li class="design web photography grid-item wow fadeInUp last-paragraph-no-margin">
                                    <figure>
                                        <div class="portfolio-img bg-deep-pink position-relative text-center overflow-hidden">
                                            <img src="<?=BASE_URL.$ls['category_image']; ?>" alt="<?=$ls['category_title']; ?>"/>
                                            <div class="portfolio-icon">
                                                <a href="<?= $ref; ?>"><i class="fas fa-link text-extra-dark-gray" aria-hidden="true"></i></a>                                                
                                            </div>
                                        </div>
                                        <figcaption class="bg-white">
                                            <div class="portfolio-hover-main text-center">
                                                <div class="portfolio-hover-box align-middle">
                                                    <div class="portfolio-hover-content position-relative">
                                                        <a href="<?= $ref; ?>"><span class="line-height-normal font-weight-600 text-small alt-font margin-5px-bottom text-extra-dark-gray text-uppercase d-block"><?=$ls['category_title']; ?></span></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </li>
                                
                                 <?php } } ?>
                                <!-- end portfolio item -->
                               
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php include 'include/vfooter.php';?>
        
        <!-- end footer -->
       
        <!-- javascript libraries -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.js" defer></script>
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/modernizr.js" defer></script>
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/bootstrap.min.js" defer></script>
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.easing.1.3.js" defer></script>
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/skrollr.min.js" defer></script>
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/smooth-scroll.js" defer></script>
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.appear.js" defer></script>
        <!-- menu navigation -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/bootsnav.js" defer></script>
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.nav.js" defer></script>
        <!-- animation -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/wow.min.js" defer></script>
        <!-- page scroll -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/page-scroll.js" defer></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/swiper.min.js" defer></script>
        <!-- counter -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.count-to.js" defer></script>
        <!-- parallax -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.stellar.js" defer></script>
        <!-- magnific popup -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.magnific-popup.min.js" defer></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/isotope.pkgd.min.js" defer></script>
        <!-- images loaded -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/imagesloaded.pkgd.min.js" defer></script>
        <!-- pull menu -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/classie.js" defer></script>
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/hamburger-menu.js" defer></script>
        <!-- counter  -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/counter.js" defer></script>
        <!-- fit video  -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.fitvids.js" defer></script>
        <!-- equalize -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/equalize.min.js" defer></script>
        <!-- skill bars  -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/skill.bars.jquery.js" defer></script> 
        <!-- justified gallery  -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/justified-gallery.min.js" defer></script>
        <!--pie chart-->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/jquery.easypiechart.min.js" defer></script>
        <!-- instagram -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/instafeed.min.js" defer></script>
        <!-- retina -->
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/retina.min.js" defer></script>
       
        <script type="text/javascript" src="<?= FRONTEND_BASE_URL; ?>/js/main.js" defer></script>
    </body>
</html>